/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;


import java.util.Scanner;


public class ComputeBMI {
    public static void main(String[] args)
	{
            double weight, height, bmi;
            Scanner src = new Scanner(System.in);
            System.out.println("ingresa tu peso en libras");
            weight = src.nextDouble();
            System.out.println("ingrese tu altura en pulgadas");
            height = src.nextDouble();
            bmi= (weight/(height*height))*703L;
            System.out.println("tu bmi es: "+ Math.round(bmi));
            src.close();
            
            
        
        }
}
