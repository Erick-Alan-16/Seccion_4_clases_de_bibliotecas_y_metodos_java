/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

import java.util.Random;



public class RockPaperScissor {

    public static void main(String[] args) {
        Random rnd = new Random();
        int rockScisorsPaper = rnd.nextInt(3);
        System.out.println(rockScisorsPaper);
        if (rockScisorsPaper==0){
            System.out.println("piedra");
        }
        if (rockScisorsPaper==1){
            System.out.println("papel");
        }
        if (rockScisorsPaper==2){
            System.out.println("tijeras");
        }
        
        

    }
}
