
package tip03;

public class CalculatorTest {
    public static void main(String[] args) {
        
       Calculator calc = new Calculator();
       
       //Use the Calculator object and arguments supplied to findTotal()
       //to print the total for each person
       
       calc.findTotal(10, "persona1 ");
       
       calc.findTotal(12, "persona2 ");
       calc.findTotal(9,"persona3 ");
       calc.findTotal(8,"persona4 ");
       calc.findTotal(7,"persona5 ");
       calc.findTotal(15,"persona6 ");
       calc.findTotal(11,"persona7 ");
       calc.findTotal(30,"persona8 ");
       
       

       
       
       /*This is what everyone owes before tax and tip:
       Person 1: $10
       Person 2: $12
       Person 3: $9
       Person 4: $8
       Person 5: $7
       Person 6: $15 (Alex)
       Person 7: $11
       Person 8: $30
       */
    }    
}
