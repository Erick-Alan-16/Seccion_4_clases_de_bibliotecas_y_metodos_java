
package tip04;

public class CalculatorTest {
    public static void main(String[] args) {
        
        Calculator calc = new Calculator();
        
        //Name your friends
       
        //System.out.println(calc.findTotal(30));
        calc.findTotal(12, null);
        calc.findTotal(9,  null);
        calc.findTotal(8,  null);
        calc.findTotal(7,  null);
        calc.findTotal(15, "Alex");
        calc.findTotal(11, null);
        calc.findTotal(30, "Forgetful");

        //Find and print the entire table's total, including tax and tip
       
        System.out.println("total sin :" + calc.total());
        
    } 
}
