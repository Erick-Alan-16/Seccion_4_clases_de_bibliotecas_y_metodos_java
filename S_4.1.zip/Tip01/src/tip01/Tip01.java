
package tip01;

public class Tip01 {
    public static void main(String[] args) {
        //Find everyone's indivudlal total after tax(5%) and tip(15%)
        
        /*This is what everyone owes before tax and tip:
        Person 1: $10
        Person 2: $12
        Person 3: $9
        Person 4: $8
        Person 5: $7
        Person 6: $15
        Person 7: $11
        Person 8: $30
        */
        
        double person1= 10;
        double total1= person1*(1+0.05+.15);
        System.out.println("person 1: $" + total1);
        
        double person2= 12;
        double total2= person2*(1+0.05+.15);
        System.out.println("person 2: $" + total2);
        
        double person3= 9;
        double total3= person3*(1+0.05+.15);
        System.out.println("person 3: $" + total3);
        
        double person4= 8;
        double total4= person4*(1+0.05+.15);
        System.out.println("person 4: $" + total4);
        
        double person5= 7;
        double total5= person5*(1+0.05+.15);
        System.out.println("person 5: $" + total5);
        
        double person6= 15;
        double total6= person6*(1+0.05+.15);
        System.out.println("person 6: $" + total6);
        
        double person7= 11;
        double total7= person7*(1+0.05+.15);
        System.out.println("person 7: $" + total7);
        
        double person8= 30;
        double total8= person8*(1+0.05+.15);
        System.out.println("person 8: $" + total8);
        
    }    
}
