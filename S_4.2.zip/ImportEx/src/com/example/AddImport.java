/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example;

//import java.util.Calendar;
//import java.util.Date;
import java.util.*;
import javax.swing.JLabel;


public class AddImport {

    public static void main(String args[]) {
        
       //javax.swing.JLabel label = new javax.swing.JLabel("hello");
            JLabel label = new JLabel();
            label.setText("que onda xd ");
    }

}
